export const QuizData = [
  {
    id: 0,
    question: `Question No 1`,
    options: [`option 1`, `option 2`, `option 3`, `option 4`],
    answer: `option 1`
  },
  {
    id: 1,
    question: `Question No 2`,
    options: [`option 1`, `option 2`, `option 3`, `option 4`],
    answer: `option 2`
  },
  {
    id: 2,
    question: `Question No 3`,
    options: [`option 1`, `option 2`, `option 3`, `option 4`],
    answer: `option 3`
  },
  {
    id: 3,
    question: `Question No 4`,
    options: [`option 1`, `option 2`, `option 3`, `option 4`],
    answer: `option 4`
  },
  {
    id: 4,
    question: `Question No 5`,
    options: [`option 1`, `option 2`, `option 3`, `option 4`],
    answer: `option 5`
  }
];
